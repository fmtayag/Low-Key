Low Key
Release version: 1.0.1
Operating System(s): Windows
Author: zyenapz
E-mail: zyenapz@gmail.com
Website: zyenapz.github.io

Hello! Thank you for downloading my game, Low Key! I hope you enjoy it :D

About
-----
Low Key is a keyboard smashing game where...you SMASH THE KEYBOARD (not actually advised)!

This game is an entry for the Finally Finish Something Jam 2021: https://itch.io/jam/finally-finish-something-2021

Controls
--------
EVERY KEY!!! Well...your alphanumeric keys (and some symbols)

Credits
--------
Programming, art, sound effects by zyenapz
Font: 'Press Start' downloaded from codeman38

------------------
Update 1.0.1 (13th February, 2021)
- Removed "O" and "0" for the mash event since the two can be confused with each other
- Changed "SMASH!" to "Press keys!" since some players found the former confusing