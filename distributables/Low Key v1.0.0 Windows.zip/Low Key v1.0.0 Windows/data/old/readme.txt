Keyboard Smasher
by Etherflux

Game Version: 3.0
Python Version: 3.7.0
Tested on: Windows 10

How to run the game
    (i) Make sure you have Python 3 installed
    (ii) Run 'KeyboardSmasher.pyw'
    (iii) If you want to wipe the highscore list, then simply delete all the content within the 'highscores.txt' file

Objectives
    (i) Try to score as high as possible under 30 seconds!

Contact information
    Website: etherflux.github.io
    E-mail: franztayag@gmail.com

Notes
    This is the second game that I uploaded to GitHub. I have rewritten the game from scratch, and I cleaned some of the code. 
    The icon is my logo, which is Holden Caulfield's red hunting hat from The Catcher in The Rye. I'm a goddamn phoney. I really am.

Big Thanks To
    MJGamerTV - for playtesting my game! He's my small cousin, by the way.
    FlameAura - for playtesting my game!

Copyright
    This .zip file / folder, and the contents within are only distributed on my website, and my github account!
    This .zip file / folder, and the contents within cannot be used for any commercial purposes without my permission!

Credits
    Font 'NONSTOP.ttf' was made by Jakob Fischer. I downloaded it from www.1001fonts.com .
        Contact Information:
        Jakob Fischer
        jakob@pizzadude.dk
        www.pizzadude.dk

Known bugs:
    (i) In the 'game' section, the symbols "blink" before they disappear. It's not game breaking, but a visual glitch.

Thank you for downloading, and enjoy!!