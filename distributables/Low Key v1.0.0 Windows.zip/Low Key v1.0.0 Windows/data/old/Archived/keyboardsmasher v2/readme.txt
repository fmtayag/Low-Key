Keyboard Smasher
by Etherflux

Game Version: 2.0
Python Version: 3.7.0
Tested on: Windows 10

How to run the game:
	(i) Simply double-click the 'game.pyw'!
	(ii) Make sure you have Python 3 installed!
	(iii) If you want to wipe the highscore list, then simply delete all the content within the 'highscore.txt' file.

Objectives:
	(i) Try to score as high as possible under 30 seconds!

Contact information
	Website: etherflux.github.io
	E-mail: franztayag@gmail.com

Notes
	This is the second game that I uploaded to GitHub. I have rewritten the game from scratch, and I cleaned some of the code. 
	Do note that I used some rather 'lazy' choices somewhere but I took my time commenting out almost all the code to explain what they do, and I hope that they are understandable.
	The icon is my logo, which is Holden Caulfield's red hunting hat from The Catcher in The Rye. I'm a goddamn phoney. I really am.

Big Thanks To
	MJGamerTV - for playtesting my game! He's my small cousin, by the way. 

Copyright
	This .zip file / folder, and the contents within are only distributed on my website, and my github account!
	This .zip file / folder, and the contents within cannot be used for any commercial purposes without my permission!

Credits
	Game soundtrack 'Off Limits' was downloaded from www.dl-sounds.com

TODO:
	(i) In the 'game' section, the symbols "blink" before they disappear. It's not game breaking, just a visual glitch.

Thank you for downloading, and enjoy!!