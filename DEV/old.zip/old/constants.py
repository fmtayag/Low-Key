## Color constants
WHITE = (255, 255, 255)
GRAY = (175, 175, 175)
GREEN = (143, 236, 40)
BLACK = (35, 35, 35)